#include "gearwidget.h"
#include <QPainter>
#include <QPainterPath>
#include <QRadialGradient>
#include <cmath>

GearWidget::GearWidget(QWidget *parent)
    : QWidget(parent)
{
    setMinimumSize(200, 260);

    m_flashAnim = new QPropertyAnimation(this, "flashAlpha", this);
    m_flashAnim->setDuration(400);
    m_flashAnim->setStartValue(1.0);
    m_flashAnim->setEndValue(0.0);
    m_flashAnim->setEasingCurve(QEasingCurve::OutQuad);

    m_scaleAnimObj = new QPropertyAnimation(this, "scaleAnim", this);
    m_scaleAnimObj->setDuration(350);
    m_scaleAnimObj->setStartValue(1.5);
    m_scaleAnimObj->setEndValue(1.0);
    m_scaleAnimObj->setEasingCurve(QEasingCurve::OutBack);

    m_group = new QSequentialAnimationGroup(this);
    m_group->addAnimation(m_flashAnim);
}

void GearWidget::updateGear(int gear)
{
    m_gear = gear;
    m_displayGear = gear;
    update();
}

void GearWidget::triggerShiftAnimation()
{
    m_displayGear = m_gear;
    if (m_group->state() == QAbstractAnimation::Running)
        m_group->stop();
    m_flashAnim->setStartValue(1.0);
    m_flashAnim->setEndValue(0.0);
    m_scaleAnimObj->setStartValue(1.6);
    m_scaleAnimObj->setEndValue(1.0);
    m_scaleAnimObj->start();
    m_group->start();
    update();
}

QSize GearWidget::sizeHint() const { return {260, 260}; }
QSize GearWidget::minimumSizeHint() const { return {180, 180}; }

void GearWidget::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);
    p.setRenderHint(QPainter::TextAntialiasing);

    QRectF rect = QRectF(0, 0, width(), height()).adjusted(8, 8, -8, -8);
    double sz = std::min(rect.width(), rect.height());
    QRectF gaugeRect(rect.center().x() - sz/2, rect.center().y() - sz/2, sz, sz);
    QPointF center = gaugeRect.center();
    double r = sz / 2.0;

    // Background circle
    QRadialGradient bg(center, r);
    bg.setColorAt(0.0, QColor(15, 25, 40));
    bg.setColorAt(0.8, QColor(8, 16, 28));
    bg.setColorAt(1.0, QColor(0, 100, 180, 60));
    p.setBrush(bg);
    p.setPen(QPen(QColor(0, 170, 255, 120), 2.5));
    p.drawEllipse(gaugeRect);

    // "GEAR" label
    QFont labelFont;
    labelFont.setPixelSize(static_cast<int>(r * 0.13));
    labelFont.setLetterSpacing(QFont::AbsoluteSpacing, 3);
    p.setFont(labelFont);
    p.setPen(QColor(0, 160, 220, 150));
    p.drawText(QRectF(center.x()-r*0.5, center.y()-r*0.75, r*1.0, r*0.25),
               Qt::AlignCenter, "GEAR");

    // Flash overlay
    if (m_flashAlpha > 0.01) {
        QRadialGradient flash(center, r * 0.8);
        flash.setColorAt(0.0, QColor(0, 220, 255, static_cast<int>(m_flashAlpha * 180)));
        flash.setColorAt(1.0, QColor(0, 150, 255, 0));
        p.setBrush(flash);
        p.setPen(Qt::NoPen);
        p.drawEllipse(center, r * 0.8, r * 0.8);
    }

    // Gear dot indicators (1-6)
    for (int i = 1; i <= 6; i++) {
        double angle = -90.0 + (i - 1) * 60.0; // evenly spaced 360/6
        double rad = qDegreesToRadians(angle);
        double dotR = r * 0.72;
        double cx = center.x() + std::cos(rad) * dotR;
        double cy = center.y() + std::sin(rad) * dotR;

        if (i <= m_displayGear) {
            // Active
            QRadialGradient dotGrad(QPointF(cx, cy), r * 0.08);
            dotGrad.setColorAt(0, QColor(0, 240, 255));
            dotGrad.setColorAt(0.5, QColor(0, 180, 230, 200));
            dotGrad.setColorAt(1.0, QColor(0, 100, 180, 0));
            p.setBrush(dotGrad);
            p.setPen(QPen(QColor(0, 220, 255), 1.5));
            p.drawEllipse(QPointF(cx, cy), r * 0.065, r * 0.065);
        } else {
            p.setBrush(QColor(30, 50, 70));
            p.setPen(QPen(QColor(50, 90, 120), 1.0));
            p.drawEllipse(QPointF(cx, cy), r * 0.05, r * 0.05);
        }
    }

    // Large gear number
    double scale = m_scaleAnim;
    p.save();
    p.translate(center);
    p.scale(scale, scale);
    p.translate(-center);

    QString gearStr = (m_displayGear == 6) ? "6" : QString::number(m_displayGear);
    QFont gearFont;
    gearFont.setPixelSize(static_cast<int>(r * 0.58));
    gearFont.setBold(true);
    gearFont.setFamily("Courier New");
    p.setFont(gearFont);

    // Glow layers
    for (int i = 3; i >= 1; i--) {
        int alpha = 40 / i;
        p.setPen(QColor(0, 200, 255, alpha));
        p.drawText(QRectF(center.x()-r*0.5, center.y()-r*0.45, r*1.0, r*0.8)
                       .adjusted(-i*2, -i*2, i*2, i*2),
                   Qt::AlignCenter, gearStr);
    }
    p.setPen(QColor(0, 230, 255));
    p.drawText(QRectF(center.x()-r*0.5, center.y()-r*0.45, r*1.0, r*0.8),
               Qt::AlignCenter, gearStr);

    p.restore();

    // Gear label below number
    QFont subFont;
    subFont.setPixelSize(static_cast<int>(r * 0.12));
    p.setFont(subFont);
    p.setPen(QColor(80, 140, 180, 180));
    QString subLabel = (m_displayGear >= 6) ? "MAX GEAR" :
                       QString("POMODORO %1").arg(m_displayGear);
    p.drawText(QRectF(center.x()-r*0.6, center.y()+r*0.45, r*1.2, r*0.22),
               Qt::AlignCenter, subLabel);
}
