QT       += core gui widgets multimedia

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++17

TARGET = FocusDrivingSimulator
TEMPLATE = app

SOURCES += \
    main.cpp \
    mainwindow.cpp \
    focusengine.cpp \
    speedgaugewidget.cpp \
    gearwidget.cpp \
    mapwidget.cpp \
    dashboardwidget.cpp

HEADERS += \
    mainwindow.h \
    focusengine.h \
    speedgaugewidget.h \
    gearwidget.h \
    mapwidget.h \
    dashboardwidget.h

# Windows-specific: link against user32 for GetForegroundWindow
win32 {
    LIBS += -luser32
}

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target
