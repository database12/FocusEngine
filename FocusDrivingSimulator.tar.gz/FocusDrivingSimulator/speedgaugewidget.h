#pragma once

#include <QWidget>
#include <QPropertyAnimation>
#include <QTimer>

class SpeedGaugeWidget : public QWidget
{
    Q_OBJECT
    Q_PROPERTY(double displaySpeed READ displaySpeed WRITE setDisplaySpeed)
    Q_PROPERTY(double glowIntensity READ glowIntensity WRITE setGlowIntensity)

public:
    explicit SpeedGaugeWidget(QWidget *parent = nullptr);

    double displaySpeed() const { return m_displaySpeed; }
    void setDisplaySpeed(double speed);

    double glowIntensity() const { return m_glowIntensity; }
    void setGlowIntensity(double v);

    void triggerGlowEffect();

public slots:
    void updateSpeed(double speed);

protected:
    void paintEvent(QPaintEvent *event) override;
    QSize sizeHint() const override;
    QSize minimumSizeHint() const override;

private:
    void drawBackground(QPainter &p, const QRectF &rect);
    void drawTicks(QPainter &p, const QPointF &center, double radius);
    void drawNeedle(QPainter &p, const QPointF &center, double radius);
    void drawSpeedLabel(QPainter &p, const QRectF &rect);
    void drawGlowRing(QPainter &p, const QPointF &center, double radius);

    double m_displaySpeed{0.0};
    double m_targetSpeed{0.0};
    double m_glowIntensity{0.0};

    QPropertyAnimation *m_speedAnim{nullptr};
    QPropertyAnimation *m_glowAnim{nullptr};
    QTimer             *m_smoothTimer{nullptr};

    static constexpr double MIN_ANGLE = -225.0; // degrees from top (start)
    static constexpr double MAX_ANGLE =  45.0;
    static constexpr double MAX_SPEED = 180.0;
};
