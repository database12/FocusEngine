#pragma once

#include <QWidget>
#include <QPropertyAnimation>
#include <QVector>
#include <QPointF>
#include <QString>

struct Waypoint {
    QString name;
    QString icon;
    double  progressAt; // 0.0–1.0
};

class MapWidget : public QWidget
{
    Q_OBJECT
    Q_PROPERTY(double carOffset READ carOffset WRITE setCarOffset)
    Q_PROPERTY(double carBounce READ carBounce WRITE setCarBounce)

public:
    explicit MapWidget(QWidget *parent = nullptr);

    double carOffset() const { return m_carOffset; }
    void setCarOffset(double v) { m_carOffset = v; update(); }

    double carBounce() const { return m_carBounce; }
    void setCarBounce(double v) { m_carBounce = v; }

public slots:
    void updateProgress(double progress);
    void updateSpeed(double speed);

protected:
    void paintEvent(QPaintEvent *) override;
    QSize sizeHint() const override;
    QSize minimumSizeHint() const override;

private:
    void drawRoad(QPainter &p, const QRectF &rect);
    void drawWaypoints(QPainter &p, const QRectF &rect);
    void drawCar(QPainter &p, const QPointF &pos, double speed);
    void drawProgressInfo(QPainter &p, const QRectF &rect);

    QPointF progressToRoadPoint(double progress, const QRectF &roadRect) const;

    double m_progress{0.0};
    double m_speed{0.0};
    double m_carOffset{0.0};
    double m_carBounce{0.0};

    QPropertyAnimation *m_progressAnim{nullptr};
    QPropertyAnimation *m_bounceAnim{nullptr};

    QVector<Waypoint> m_waypoints;

    // Road control points for a smooth S-curve
    static constexpr int ROAD_SEGMENTS = 200;
};
