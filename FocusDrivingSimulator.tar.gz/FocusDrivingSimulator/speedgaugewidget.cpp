#include "speedgaugewidget.h"
#include <QPainter>
#include <QPainterPath>
#include <QRadialGradient>
#include <QConicalGradient>
#include <QLinearGradient>
#include <QFontDatabase>
#include <cmath>

SpeedGaugeWidget::SpeedGaugeWidget(QWidget *parent)
    : QWidget(parent)
{
    setMinimumSize(260, 260);
    setAttribute(Qt::WA_TranslucentBackground, false);

    m_speedAnim = new QPropertyAnimation(this, "displaySpeed", this);
    m_speedAnim->setDuration(800);
    m_speedAnim->setEasingCurve(QEasingCurve::OutCubic);

    m_glowAnim = new QPropertyAnimation(this, "glowIntensity", this);
    m_glowAnim->setDuration(600);
    m_glowAnim->setEasingCurve(QEasingCurve::OutQuad);
}

void SpeedGaugeWidget::updateSpeed(double speed)
{
    m_targetSpeed = speed;
    if (m_speedAnim->state() == QAbstractAnimation::Running)
        m_speedAnim->stop();
    m_speedAnim->setStartValue(m_displaySpeed);
    m_speedAnim->setEndValue(speed);
    m_speedAnim->start();
}

void SpeedGaugeWidget::setDisplaySpeed(double speed)
{
    m_displaySpeed = speed;
    update();
}

void SpeedGaugeWidget::setGlowIntensity(double v)
{
    m_glowIntensity = v;
    update();
}

void SpeedGaugeWidget::triggerGlowEffect()
{
    if (m_glowAnim->state() == QAbstractAnimation::Running)
        m_glowAnim->stop();
    m_glowAnim->setStartValue(1.0);
    m_glowAnim->setEndValue(0.0);
    m_glowAnim->start();
}

QSize SpeedGaugeWidget::sizeHint() const { return {300, 300}; }
QSize SpeedGaugeWidget::minimumSizeHint() const { return {200, 200}; }

void SpeedGaugeWidget::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing, true);
    p.setRenderHint(QPainter::TextAntialiasing, true);

    QRectF rect = QRectF(0, 0, width(), height()).adjusted(8, 8, -8, -8);
    double sz = std::min(rect.width(), rect.height());
    QRectF gaugeRect(rect.center().x() - sz/2, rect.center().y() - sz/2, sz, sz);
    QPointF center = gaugeRect.center();
    double radius = sz / 2.0;

    drawBackground(p, gaugeRect);
    drawGlowRing(p, center, radius);
    drawTicks(p, center, radius);
    drawNeedle(p, center, radius);
    drawSpeedLabel(p, gaugeRect);
}

void SpeedGaugeWidget::drawBackground(QPainter &p, const QRectF &rect)
{
    QPointF center = rect.center();
    double r = std::min(rect.width(), rect.height()) / 2.0;

    // Outer dark ring
    QRadialGradient outerGrad(center, r);
    outerGrad.setColorAt(0.0, QColor(15, 25, 40));
    outerGrad.setColorAt(0.75, QColor(8, 16, 28));
    outerGrad.setColorAt(1.0, QColor(0, 120, 200, 60));
    p.setBrush(outerGrad);
    p.setPen(QPen(QColor(0, 170, 255, 120), 2.5));
    p.drawEllipse(rect);

    // Inner subtle gradient
    QRadialGradient innerGrad(center, r * 0.65);
    innerGrad.setColorAt(0.0, QColor(20, 35, 55));
    innerGrad.setColorAt(1.0, QColor(10, 20, 35, 0));
    p.setBrush(innerGrad);
    p.setPen(Qt::NoPen);
    p.drawEllipse(center, r * 0.65, r * 0.65);

    // Speedo arc (colored zone)
    double startAngle = 225.0;   // Qt: 0=3o'clock, CCW
    double spanAngle  = -270.0;  // 270 degrees sweep
    QPen arcPen;
    arcPen.setCapStyle(Qt::FlatCap);
    arcPen.setWidth(static_cast<int>(r * 0.06));

    // Green zone 0-60
    arcPen.setColor(QColor(0, 200, 120, 80));
    p.setPen(arcPen);
    p.drawArc(QRectF(center.x()-r*0.82, center.y()-r*0.82, r*1.64, r*1.64),
              static_cast<int>(startAngle*16),
              static_cast<int>(-90*16));

    // Orange zone 60-120
    arcPen.setColor(QColor(255, 140, 0, 80));
    p.setPen(arcPen);
    p.drawArc(QRectF(center.x()-r*0.82, center.y()-r*0.82, r*1.64, r*1.64),
              static_cast<int>((startAngle-90)*16),
              static_cast<int>(-90*16));

    // Red zone 120-180
    arcPen.setColor(QColor(255, 50, 50, 80));
    p.setPen(arcPen);
    p.drawArc(QRectF(center.x()-r*0.82, center.y()-r*0.82, r*1.64, r*1.64),
              static_cast<int>((startAngle-180)*16),
              static_cast<int>(-90*16));
}

void SpeedGaugeWidget::drawTicks(QPainter &p, const QPointF &center, double radius)
{
    // Major ticks at each 20 km/h (0..180 = 10 marks)
    // Arc goes from -225 deg (at 12 o'clock minus 45) to +45 deg = 270 deg sweep
    // 0 km/h = -225 deg from east = 135 deg from top
    // Angle formula: angle = -225 + (speed/180)*270  (degrees from east, CCW = negative)
    // In Qt: 0=3o'clock, CCW = positive

    for (int speed = 0; speed <= 180; speed += 20) {
        double t = static_cast<double>(speed) / 180.0;
        // Map: 0 -> 225deg, 180 -> 225-270=-45 (= 315 deg)
        double angleDeg = 225.0 - t * 270.0; // degrees from 3-o'clock, CCW
        double angleRad = qDegreesToRadians(angleDeg);

        double cosA = std::cos(angleRad);
        double sinA = -std::sin(angleRad); // Qt Y is inverted

        double outerR = radius * 0.88;
        double innerR = radius * 0.74;
        QPointF outer(center.x() + cosA * outerR, center.y() + sinA * outerR);
        QPointF inner(center.x() + cosA * innerR, center.y() + sinA * innerR);

        p.setPen(QPen(QColor(0, 200, 255, 200), 2.5));
        p.drawLine(outer, inner);

        // Label
        double labelR = radius * 0.62;
        QPointF labelPos(center.x() + cosA * labelR - 14, center.y() + sinA * labelR - 10);

        QFont f;
        f.setPixelSize(static_cast<int>(radius * 0.11));
        f.setBold(true);
        p.setFont(f);
        p.setPen(QColor(180, 220, 255, 200));
        p.drawText(QRectF(labelPos, QSizeF(28, 20)), Qt::AlignCenter, QString::number(speed));
    }

    // Minor ticks at each 10 km/h
    for (int speed = 0; speed <= 180; speed += 10) {
        if (speed % 20 == 0) continue;
        double t = static_cast<double>(speed) / 180.0;
        double angleDeg = 225.0 - t * 270.0;
        double angleRad = qDegreesToRadians(angleDeg);
        double cosA = std::cos(angleRad);
        double sinA = -std::sin(angleRad);

        double outerR = radius * 0.88;
        double innerR = radius * 0.81;
        QPointF outer(center.x() + cosA * outerR, center.y() + sinA * outerR);
        QPointF inner(center.x() + cosA * innerR, center.y() + sinA * innerR);
        p.setPen(QPen(QColor(0, 150, 200, 120), 1.5));
        p.drawLine(outer, inner);
    }
}

void SpeedGaugeWidget::drawNeedle(QPainter &p, const QPointF &center, double radius)
{
    double t = m_displaySpeed / 180.0;
    double angleDeg = 225.0 - t * 270.0;
    double angleRad = qDegreesToRadians(angleDeg);

    double cosA = std::cos(angleRad);
    double sinA = -std::sin(angleRad);

    // Needle
    double needleLen = radius * 0.70;
    double tailLen   = radius * 0.15;
    QPointF tip (center.x() + cosA * needleLen, center.y() + sinA * needleLen);
    QPointF tail(center.x() - cosA * tailLen,   center.y() - sinA * tailLen);

    // Glow beneath needle
    QPen glowPen(QColor(255, 100, 0, 60), 8);
    glowPen.setCapStyle(Qt::RoundCap);
    p.setPen(glowPen);
    p.drawLine(tail, tip);

    QPen needlePen(QColor(255, 140, 20), 3);
    needlePen.setCapStyle(Qt::RoundCap);
    p.setPen(needlePen);
    p.drawLine(tail, tip);

    // Center hub
    QRadialGradient hubGrad(center, radius * 0.07);
    hubGrad.setColorAt(0, QColor(255, 200, 100));
    hubGrad.setColorAt(1, QColor(180, 80, 0));
    p.setBrush(hubGrad);
    p.setPen(QPen(QColor(255, 160, 50), 1.5));
    p.drawEllipse(center, radius * 0.07, radius * 0.07);
}

void SpeedGaugeWidget::drawSpeedLabel(QPainter &p, const QRectF &rect)
{
    QPointF center = rect.center();
    double r = std::min(rect.width(), rect.height()) / 2.0;

    // Speed value
    QFont bigFont;
    bigFont.setPixelSize(static_cast<int>(r * 0.30));
    bigFont.setBold(true);
    bigFont.setFamily("Courier New");
    p.setFont(bigFont);

    // Glow text effect
    p.setPen(QColor(0, 200, 255, 60));
    QRectF textRect(center.x() - r*0.5, center.y() + r*0.18, r*1.0, r*0.35);
    for (int i = 0; i < 3; i++) {
        p.drawText(textRect.adjusted(-i, -i, i, i), Qt::AlignCenter,
                   QString::number(static_cast<int>(m_displaySpeed)));
    }
    p.setPen(QColor(0, 230, 255));
    p.drawText(textRect, Qt::AlignCenter, QString::number(static_cast<int>(m_displaySpeed)));

    // km/h label
    QFont smallFont;
    smallFont.setPixelSize(static_cast<int>(r * 0.13));
    p.setFont(smallFont);
    p.setPen(QColor(100, 160, 200, 200));
    p.drawText(QRectF(center.x() - r*0.4, center.y() + r*0.45, r*0.8, r*0.2),
               Qt::AlignCenter, "km/h");

    // Title
    QFont titleFont;
    titleFont.setPixelSize(static_cast<int>(r * 0.11));
    titleFont.setLetterSpacing(QFont::AbsoluteSpacing, 2);
    p.setFont(titleFont);
    p.setPen(QColor(0, 160, 220, 150));
    p.drawText(QRectF(center.x() - r*0.5, center.y() - r*0.90, r*1.0, r*0.2),
               Qt::AlignCenter, "FOCUS SPEED");
}

void SpeedGaugeWidget::drawGlowRing(QPainter &p, const QPointF &center, double radius)
{
    if (m_glowIntensity < 0.01) return;

    QRadialGradient glow(center, radius);
    int alpha = static_cast<int>(m_glowIntensity * 120);
    glow.setColorAt(0.75, QColor(0, 180, 255, 0));
    glow.setColorAt(0.88, QColor(0, 200, 255, alpha));
    glow.setColorAt(1.00, QColor(0, 100, 200, 0));
    p.setBrush(glow);
    p.setPen(Qt::NoPen);
    p.drawEllipse(center, radius, radius);
}
