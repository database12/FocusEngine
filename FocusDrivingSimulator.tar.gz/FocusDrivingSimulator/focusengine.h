#pragma once

#include <QObject>
#include <QTimer>
#include <QElapsedTimer>
#include <cmath>

#ifdef Q_OS_WIN
#include <windows.h>
#endif

class FocusEngine : public QObject
{
    Q_OBJECT
    Q_PROPERTY(double speed READ speed NOTIFY speedChanged)
    Q_PROPERTY(int gear READ gear NOTIFY gearChanged)
    Q_PROPERTY(double progress READ progress NOTIFY progressChanged)

public:
    enum class State { Idle, Running, Paused };

    explicit FocusEngine(QObject *parent = nullptr);
    ~FocusEngine() override;

    // Install as global event filter on QApplication
    bool eventFilter(QObject *watched, QEvent *event) override;

    double speed() const { return m_speed; }
    int    gear()  const { return m_gear; }
    double progress() const { return m_progress; }

    int focusTimeSeconds() const { return m_focusTimeSeconds; }
    State state() const { return m_state; }

    // session goal in seconds (default 5 pomodoros = 7500 s)
    void setSessionGoal(int seconds) { m_sessionGoalSeconds = seconds; }
    int  sessionGoal() const { return m_sessionGoalSeconds; }

    int totalDistractionsCount() const { return m_totalDistractions; }
    int totalIdlePenalties() const { return m_totalIdlePenalties; }

public slots:
    void start();
    void pause();
    void reset();

signals:
    void speedChanged(double speed);
    void gearChanged(int gear);
    void progressChanged(double progress);
    void gearShiftTriggered(int newGear);
    void stateChanged(FocusEngine::State state);
    void sessionCompleted();

private slots:
    void onTick();
    void onClickRateTimer();

private:
    void applySpeedClamp();
    void updateGear();
    void checkWindowFocus();

    State   m_state{State::Idle};
    int     m_focusTimeSeconds{0};
    double  m_speed{0.0};
    int     m_gear{1};
    double  m_progress{0.0};
    int     m_sessionGoalSeconds{7500}; // 5 pomodoros

    // Timers
    QTimer *m_tickTimer{nullptr};
    QTimer *m_clickRateTimer{nullptr};

    // Idle detection
    qint64  m_lastInputTime{0};
    int     m_idleSeconds{0};
    static constexpr int    IDLE_THRESHOLD_SECONDS = 30;
    static constexpr double IDLE_PENALTY_PER_SECOND = 0.2;

    // Click detection
    int     m_clickCountThisSecond{0};
    int     m_totalDistractedClicks{0};
    static constexpr int CLICK_RATE_THRESHOLD = 5; // clicks per second
    static constexpr double CLICK_PENALTY = 5.0;

    // Window focus
    bool    m_appHadFocus{true};
    static constexpr double FOCUS_LOSS_PENALTY = 10.0;

    // Statistics
    int     m_totalDistractions{0};
    int     m_totalIdlePenalties{0};

    // Speed computation
    double computeTargetSpeed() const;
};
