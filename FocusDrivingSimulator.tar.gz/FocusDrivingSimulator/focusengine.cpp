#include "focusengine.h"
#include <QApplication>
#include <QEvent>
#include <QMouseEvent>
#include <QKeyEvent>
#include <QDateTime>
#include <algorithm>

FocusEngine::FocusEngine(QObject *parent)
    : QObject(parent)
{
    m_lastInputTime = QDateTime::currentMSecsSinceEpoch();

    m_tickTimer = new QTimer(this);
    m_tickTimer->setInterval(1000);
    connect(m_tickTimer, &QTimer::timeout, this, &FocusEngine::onTick);

    m_clickRateTimer = new QTimer(this);
    m_clickRateTimer->setInterval(1000);
    connect(m_clickRateTimer, &QTimer::timeout, this, &FocusEngine::onClickRateTimer);

    // Install as global event filter
    qApp->installEventFilter(this);
}

FocusEngine::~FocusEngine()
{
    if (qApp) qApp->removeEventFilter(this);
}

bool FocusEngine::eventFilter(QObject *watched, QEvent *event)
{
    Q_UNUSED(watched)
    if (m_state != State::Running) return false;

    if (event->type() == QEvent::MouseButtonPress) {
        m_lastInputTime = QDateTime::currentMSecsSinceEpoch();
        m_idleSeconds = 0;
        m_clickCountThisSecond++;
    } else if (event->type() == QEvent::KeyPress) {
        m_lastInputTime = QDateTime::currentMSecsSinceEpoch();
        m_idleSeconds = 0;
    }
    return false; // never consume the event
}

void FocusEngine::start()
{
    if (m_state == State::Running) return;
    m_state = State::Running;
    m_lastInputTime = QDateTime::currentMSecsSinceEpoch();
    m_tickTimer->start();
    m_clickRateTimer->start();
    emit stateChanged(m_state);
}

void FocusEngine::pause()
{
    if (m_state != State::Running) return;
    m_state = State::Paused;
    m_tickTimer->stop();
    m_clickRateTimer->stop();
    emit stateChanged(m_state);
}

void FocusEngine::reset()
{
    m_tickTimer->stop();
    m_clickRateTimer->stop();
    m_state = State::Idle;
    m_focusTimeSeconds = 0;
    m_speed = 0.0;
    m_gear = 1;
    m_progress = 0.0;
    m_idleSeconds = 0;
    m_clickCountThisSecond = 0;
    m_totalDistractions = 0;
    m_totalIdlePenalties = 0;

    emit speedChanged(m_speed);
    emit gearChanged(m_gear);
    emit progressChanged(m_progress);
    emit stateChanged(m_state);
}

double FocusEngine::computeTargetSpeed() const
{
    // Momentum curve: asymptotically approaches 180 km/h
    // 1200 second time constant: ~80 km/h at 25 min, ~140 km/h at 50 min
    return 180.0 * (1.0 - std::exp(-static_cast<double>(m_focusTimeSeconds) / 1200.0));
}

void FocusEngine::onTick()
{
    m_focusTimeSeconds++;

    // --- Idle detection ---
    qint64 now = QDateTime::currentMSecsSinceEpoch();
    qint64 timeSinceInput = now - m_lastInputTime;
    if (timeSinceInput > IDLE_THRESHOLD_SECONDS * 1000LL) {
        m_idleSeconds++;
        double penalty = m_idleSeconds * IDLE_PENALTY_PER_SECOND;
        m_speed = std::max(0.0, m_speed - penalty);
        m_totalIdlePenalties++;
    } else {
        m_idleSeconds = 0;
        // Smoothly approach target speed
        double target = computeTargetSpeed();
        double delta = target - m_speed;
        m_speed += delta * 0.05; // smooth approach
    }

    // --- Window focus check (non-Windows graceful fallback) ---
    checkWindowFocus();

    applySpeedClamp();
    updateGear();

    // Progress
    double newProgress = std::min(1.0, static_cast<double>(m_focusTimeSeconds) / m_sessionGoalSeconds);
    if (newProgress != m_progress) {
        m_progress = newProgress;
        emit progressChanged(m_progress);
    }

    emit speedChanged(m_speed);

    if (m_focusTimeSeconds >= m_sessionGoalSeconds) {
        pause();
        emit sessionCompleted();
    }
}

void FocusEngine::onClickRateTimer()
{
    if (m_clickCountThisSecond > CLICK_RATE_THRESHOLD) {
        m_speed = std::max(0.0, m_speed - CLICK_PENALTY);
        m_totalDistractions++;
        emit speedChanged(m_speed);
    }
    m_clickCountThisSecond = 0;
}

void FocusEngine::checkWindowFocus()
{
#ifdef Q_OS_WIN
    HWND foreground = GetForegroundWindow();
    // Get any top-level widget handle from our app
    bool appHasFocus = false;
    for (QWidget *w : QApplication::topLevelWidgets()) {
        if (reinterpret_cast<HWND>(w->winId()) == foreground) {
            appHasFocus = true;
            break;
        }
    }
    if (!appHasFocus && m_appHadFocus) {
        m_speed = std::max(0.0, m_speed - FOCUS_LOSS_PENALTY);
        m_totalDistractions++;
        emit speedChanged(m_speed);
    }
    m_appHadFocus = appHasFocus;
#else
    // On non-Windows: use Qt's focus change signal instead (connected in MainWindow)
    bool appHasFocus = (QApplication::activeWindow() != nullptr);
    if (!appHasFocus && m_appHadFocus) {
        m_speed = std::max(0.0, m_speed - FOCUS_LOSS_PENALTY);
        m_totalDistractions++;
        emit speedChanged(m_speed);
    }
    m_appHadFocus = appHasFocus;
#endif
}

void FocusEngine::applySpeedClamp()
{
    m_speed = std::max(0.0, std::min(180.0, m_speed));
}

void FocusEngine::updateGear()
{
    // 1 Pomodoro = 1500 seconds, max gear 6
    int newGear = std::min(6, m_focusTimeSeconds / 1500 + 1);
    if (newGear != m_gear) {
        m_gear = newGear;
        emit gearChanged(m_gear);
        emit gearShiftTriggered(m_gear);
    }
}
