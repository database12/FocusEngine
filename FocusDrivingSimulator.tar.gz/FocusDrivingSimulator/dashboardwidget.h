#pragma once

#include <QWidget>
#include <QPropertyAnimation>
#include <QLabel>
#include <QPushButton>
#include <QTimer>

class FocusEngine;
class SpeedGaugeWidget;
class GearWidget;
class MapWidget;

class DashboardWidget : public QWidget
{
    Q_OBJECT
    Q_PROPERTY(double flashAlpha READ flashAlpha WRITE setFlashAlpha)

public:
    explicit DashboardWidget(QWidget *parent = nullptr);

    double flashAlpha() const { return m_flashAlpha; }
    void setFlashAlpha(double v) { m_flashAlpha = v; update(); }

protected:
    void paintEvent(QPaintEvent *) override;

private slots:
    void onGearShifted(int gear);
    void onSessionCompleted();
    void onStateChanged();
    void updateStatusBar();

private:
    void setupUI();
    void setupConnections();
    void styleButton(QPushButton *btn, const QColor &accent);

    FocusEngine     *m_engine{nullptr};
    SpeedGaugeWidget *m_speedGauge{nullptr};
    GearWidget       *m_gearWidget{nullptr};
    MapWidget        *m_mapWidget{nullptr};

    QPushButton *m_startBtn{nullptr};
    QPushButton *m_pauseBtn{nullptr};
    QPushButton *m_resetBtn{nullptr};

    QLabel *m_timerLabel{nullptr};
    QLabel *m_statusLabel{nullptr};
    QLabel *m_statsLabel{nullptr};

    QTimer *m_statusTimer{nullptr};

    QPropertyAnimation *m_flashAnim{nullptr};
    double m_flashAlpha{0.0};
};
