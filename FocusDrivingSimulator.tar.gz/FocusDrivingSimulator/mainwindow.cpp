#include "mainwindow.h"
#include "dashboardwidget.h"
#include <QResizeEvent>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setWindowTitle("Focus Driving Simulator");
    setMinimumSize(900, 680);
    resize(1100, 760);

    // Dark title bar on Windows (Qt 6.x)
#if defined(Q_OS_WIN) && QT_VERSION >= QT_VERSION_CHECK(6, 0, 0)
    // Use platform API if available; graceful fallback otherwise
#endif

    m_dashboard = new DashboardWidget(this);
    setCentralWidget(m_dashboard);

    // Frameless dark look
    setStyleSheet("QMainWindow { background: #060C16; }");
}

void MainWindow::resizeEvent(QResizeEvent *event)
{
    QMainWindow::resizeEvent(event);
}
