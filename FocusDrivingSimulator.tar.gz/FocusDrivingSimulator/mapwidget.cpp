#include "mapwidget.h"
#include <QPainter>
#include <QPainterPath>
#include <QLinearGradient>
#include <QRadialGradient>
#include <cmath>

MapWidget::MapWidget(QWidget *parent)
    : QWidget(parent)
{
    setMinimumSize(400, 200);

    m_waypoints = {
        { "HOME",        "🏠", 0.00 },
        { "FOREST",      "🌲", 0.20 },
        { "MOUNTAIN",    "⛰",  0.40 },
        { "TUNNEL",      "🚇", 0.60 },
        { "CITY",        "🏙",  0.80 },
        { "DESTINATION", "🏁", 1.00 },
    };

    m_progressAnim = new QPropertyAnimation(this, "carOffset", this);
    m_progressAnim->setDuration(1000);
    m_progressAnim->setEasingCurve(QEasingCurve::OutCubic);

    m_bounceAnim = new QPropertyAnimation(this, "carBounce", this);
    m_bounceAnim->setDuration(400);
    m_bounceAnim->setLoopCount(-1);
    m_bounceAnim->setStartValue(0.0);
    m_bounceAnim->setEndValue(1.0);
    m_bounceAnim->setEasingCurve(QEasingCurve::InOutSine);
}

void MapWidget::updateProgress(double progress)
{
    if (m_progressAnim->state() == QAbstractAnimation::Running)
        m_progressAnim->stop();
    m_progressAnim->setStartValue(m_carOffset);
    m_progressAnim->setEndValue(progress);
    m_progressAnim->start();
    m_progress = progress;
}

void MapWidget::updateSpeed(double speed)
{
    m_speed = speed;
    if (speed > 5.0 && m_bounceAnim->state() != QAbstractAnimation::Running) {
        m_bounceAnim->start();
    } else if (speed <= 5.0 && m_bounceAnim->state() == QAbstractAnimation::Running) {
        m_bounceAnim->stop();
    }
    update();
}

QSize MapWidget::sizeHint() const { return {600, 220}; }
QSize MapWidget::minimumSizeHint() const { return {350, 160}; }

QPointF MapWidget::progressToRoadPoint(double progress, const QRectF &roadRect) const
{
    // Simple S-curve through the road area
    double t = progress;
    double x = roadRect.left() + t * roadRect.width();
    // Gentle sine wave for road
    double amplitude = roadRect.height() * 0.20;
    double y = roadRect.center().y() + amplitude * std::sin(t * M_PI * 2.0);
    return QPointF(x, y);
}

void MapWidget::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);
    p.setRenderHint(QPainter::TextAntialiasing);

    QRectF rect(0, 0, width(), height());

    // Background
    QLinearGradient bg(rect.topLeft(), rect.bottomLeft());
    bg.setColorAt(0, QColor(5, 12, 22));
    bg.setColorAt(1, QColor(10, 20, 35));
    p.fillRect(rect, bg);

    // Panel border
    p.setPen(QPen(QColor(0, 140, 200, 80), 1.5));
    p.setBrush(Qt::NoBrush);
    p.drawRoundedRect(rect.adjusted(2,2,-2,-2), 8, 8);

    // Road area
    QRectF roadRect = rect.adjusted(40, 40, -40, -50);
    drawRoad(p, roadRect);
    drawWaypoints(p, roadRect);

    // Car
    QPointF carPos = progressToRoadPoint(m_carOffset, roadRect);
    double bounce = std::sin(m_carBounce * M_PI) * 3.0;
    carPos.setY(carPos.y() + bounce);
    drawCar(p, carPos, m_speed);

    drawProgressInfo(p, rect);
}

void MapWidget::drawRoad(QPainter &p, const QRectF &roadRect)
{
    QPainterPath roadPath;
    bool first = true;
    for (int i = 0; i <= ROAD_SEGMENTS; i++) {
        double t = static_cast<double>(i) / ROAD_SEGMENTS;
        QPointF pt = progressToRoadPoint(t, roadRect);
        if (first) { roadPath.moveTo(pt); first = false; }
        else roadPath.lineTo(pt);
    }

    // Road shadow / glow beneath
    QPen shadowPen(QColor(0, 100, 180, 40), 18);
    shadowPen.setCapStyle(Qt::RoundCap);
    p.setPen(shadowPen);
    p.setBrush(Qt::NoBrush);
    p.drawPath(roadPath);

    // Road surface
    QPen roadPen(QColor(30, 50, 70), 12);
    roadPen.setCapStyle(Qt::RoundCap);
    p.setPen(roadPen);
    p.drawPath(roadPath);

    // Road center line (dashed)
    QPen dashPen(QColor(0, 180, 255, 100), 2, Qt::DashLine);
    dashPen.setDashPattern({8, 8});
    dashPen.setCapStyle(Qt::RoundCap);
    p.setPen(dashPen);
    p.drawPath(roadPath);

    // Completed (driven) portion – brighter
    QPainterPath drivenPath;
    bool firstD = true;
    for (int i = 0; i <= ROAD_SEGMENTS; i++) {
        double t = static_cast<double>(i) / ROAD_SEGMENTS;
        if (t > m_carOffset + 0.005) break;
        QPointF pt = progressToRoadPoint(t, roadRect);
        if (firstD) { drivenPath.moveTo(pt); firstD = false; }
        else drivenPath.lineTo(pt);
    }
    QPen drivenPen(QColor(0, 200, 255, 120), 12);
    drivenPen.setCapStyle(Qt::RoundCap);
    p.setPen(drivenPen);
    p.drawPath(drivenPath);
}

void MapWidget::drawWaypoints(QPainter &p, const QRectF &roadRect)
{
    for (const auto &wp : m_waypoints) {
        QPointF pos = progressToRoadPoint(wp.progressAt, roadRect);
        bool reached = (m_carOffset >= wp.progressAt - 0.01);

        // Dot
        QColor dotColor = reached ? QColor(0, 220, 255) : QColor(60, 100, 140);
        QColor glowColor = reached ? QColor(0, 180, 255, 80) : QColor(40, 80, 120, 40);
        p.setBrush(glowColor);
        p.setPen(Qt::NoPen);
        p.drawEllipse(pos, 14, 14);
        p.setBrush(dotColor);
        p.setPen(QPen(reached ? QColor(100, 240, 255) : QColor(80, 120, 160), 1.5));
        p.drawEllipse(pos, 6, 6);

        // Name label
        QFont f;
        f.setPixelSize(9);
        f.setLetterSpacing(QFont::AbsoluteSpacing, 1);
        p.setFont(f);
        p.setPen(reached ? QColor(0, 200, 255, 200) : QColor(80, 120, 160, 160));
        QRectF labelRect(pos.x() - 40, pos.y() + 14, 80, 18);
        p.drawText(labelRect, Qt::AlignCenter, wp.name);
    }
}

void MapWidget::drawCar(QPainter &p, const QPointF &pos, double speed)
{
    Q_UNUSED(speed)
    p.save();
    p.translate(pos);

    // Car glow
    QRadialGradient glow(QPointF(0,0), 24);
    glow.setColorAt(0, QColor(0, 200, 255, 80));
    glow.setColorAt(1, QColor(0, 100, 200, 0));
    p.setBrush(glow);
    p.setPen(Qt::NoPen);
    p.drawEllipse(QPointF(0,0), 24, 24);

    // Car body (simplified side view)
    QPainterPath car;
    car.moveTo(-14, 4);
    car.lineTo(-14, 0);
    car.cubicTo(-12, -10, -6, -12, 0, -12);
    car.cubicTo(6, -12, 12, -10, 14, 0);
    car.lineTo(14, 4);
    car.closeSubpath();

    QLinearGradient carGrad(QPointF(0,-12), QPointF(0,4));
    carGrad.setColorAt(0, QColor(0, 180, 255));
    carGrad.setColorAt(0.5, QColor(0, 120, 200));
    carGrad.setColorAt(1.0, QColor(0, 60, 120));
    p.setBrush(carGrad);
    p.setPen(QPen(QColor(100, 220, 255), 1.0));
    p.drawPath(car);

    // Wheels
    p.setBrush(QColor(20, 30, 50));
    p.setPen(QPen(QColor(0, 150, 220), 1.0));
    p.drawEllipse(QPointF(-9, 5), 5, 5);
    p.drawEllipse(QPointF( 9, 5), 5, 5);

    // Headlight glow
    QRadialGradient headlight(QPointF(16, 0), 10);
    headlight.setColorAt(0, QColor(255, 240, 200, 180));
    headlight.setColorAt(1, QColor(255, 200, 100, 0));
    p.setBrush(headlight);
    p.setPen(Qt::NoPen);
    p.drawEllipse(QPointF(16, 0), 10, 5);

    p.restore();
}

void MapWidget::drawProgressInfo(QPainter &p, const QRectF &rect)
{
    // Progress bar at bottom
    QRectF barBg(rect.left()+10, rect.bottom()-20, rect.width()-20, 10);
    p.setBrush(QColor(15, 30, 50));
    p.setPen(QPen(QColor(0, 100, 160), 1));
    p.drawRoundedRect(barBg, 5, 5);

    double fillW = barBg.width() * m_carOffset;
    if (fillW > 0) {
        QLinearGradient fill(barBg.topLeft(), QPointF(barBg.right(), barBg.top()));
        fill.setColorAt(0, QColor(0, 160, 220));
        fill.setColorAt(1, QColor(0, 230, 255));
        p.setBrush(fill);
        p.setPen(Qt::NoPen);
        p.drawRoundedRect(QRectF(barBg.left(), barBg.top(), fillW, barBg.height()), 5, 5);
    }

    // Progress text
    QFont pf;
    pf.setPixelSize(11);
    p.setFont(pf);
    p.setPen(QColor(0, 180, 220, 180));
    p.drawText(QRectF(rect.right()-70, rect.bottom()-22, 65, 14),
               Qt::AlignRight | Qt::AlignVCenter,
               QString("%1%").arg(static_cast<int>(m_carOffset * 100)));

    // Trip label
    p.setPen(QColor(0, 140, 180, 150));
    p.drawText(QRectF(rect.left()+8, rect.bottom()-22, 120, 14),
               Qt::AlignLeft | Qt::AlignVCenter, "TRIP PROGRESS");
}
