#include "dashboardwidget.h"
#include "focusengine.h"
#include "speedgaugewidget.h"
#include "gearwidget.h"
#include "mapwidget.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QPainter>
#include <QLinearGradient>
#include <QRadialGradient>
#include <QFont>
#include <QTimer>
#include <QSizePolicy>

DashboardWidget::DashboardWidget(QWidget *parent)
    : QWidget(parent)
{
    m_engine = new FocusEngine(this);
    setupUI();
    setupConnections();

    m_flashAnim = new QPropertyAnimation(this, "flashAlpha", this);
    m_flashAnim->setDuration(500);
    m_flashAnim->setStartValue(0.8);
    m_flashAnim->setEndValue(0.0);
    m_flashAnim->setEasingCurve(QEasingCurve::OutQuad);

    m_statusTimer = new QTimer(this);
    m_statusTimer->setInterval(1000);
    connect(m_statusTimer, &QTimer::timeout, this, &DashboardWidget::updateStatusBar);
    m_statusTimer->start();
}

void DashboardWidget::setupUI()
{
    setMinimumSize(900, 680);
    setStyleSheet("QWidget { background: transparent; }");

    auto *rootLayout = new QVBoxLayout(this);
    rootLayout->setContentsMargins(16, 12, 16, 12);
    rootLayout->setSpacing(8);

    // ── Title bar ─────────────────────────────────────────────
    auto *titleRow = new QHBoxLayout;
    QLabel *titleLabel = new QLabel("FOCUS DRIVING SIMULATOR");
    QFont titleFont;
    titleFont.setFamily("Courier New");
    titleFont.setPixelSize(22);
    titleFont.setBold(true);
    titleFont.setLetterSpacing(QFont::AbsoluteSpacing, 6);
    titleLabel->setFont(titleFont);
    titleLabel->setStyleSheet("color: rgba(0,200,255,220); background: transparent;");
    titleLabel->setAlignment(Qt::AlignCenter);
    titleRow->addWidget(titleLabel);
    rootLayout->addLayout(titleRow);

    // ── Timer & status row ────────────────────────────────────
    auto *statusRow = new QHBoxLayout;
    m_timerLabel = new QLabel("00:00:00");
    QFont timerFont;
    timerFont.setFamily("Courier New");
    timerFont.setPixelSize(26);
    timerFont.setBold(true);
    m_timerLabel->setFont(timerFont);
    m_timerLabel->setStyleSheet("color: rgba(0,230,255,255); background: transparent;");
    m_timerLabel->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);

    m_statusLabel = new QLabel("● IDLE");
    QFont statusFont;
    statusFont.setPixelSize(13);
    statusFont.setLetterSpacing(QFont::AbsoluteSpacing, 2);
    m_statusLabel->setFont(statusFont);
    m_statusLabel->setStyleSheet("color: rgba(100,160,200,200); background: transparent;");
    m_statusLabel->setAlignment(Qt::AlignCenter);

    m_statsLabel = new QLabel("Distractions: 0  |  Idle penalties: 0");
    QFont statsFont;
    statsFont.setPixelSize(11);
    m_statsLabel->setFont(statsFont);
    m_statsLabel->setStyleSheet("color: rgba(80,130,170,180); background: transparent;");
    m_statsLabel->setAlignment(Qt::AlignRight | Qt::AlignVCenter);

    statusRow->addWidget(m_timerLabel, 1);
    statusRow->addWidget(m_statusLabel, 2);
    statusRow->addWidget(m_statsLabel, 1);
    rootLayout->addLayout(statusRow);

    // ── Gauges row ────────────────────────────────────────────
    auto *gaugesRow = new QHBoxLayout;
    gaugesRow->setSpacing(12);

    m_speedGauge = new SpeedGaugeWidget(this);
    m_speedGauge->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    m_gearWidget = new GearWidget(this);
    m_gearWidget->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    gaugesRow->addWidget(m_speedGauge, 1);
    gaugesRow->addWidget(m_gearWidget, 1);
    rootLayout->addLayout(gaugesRow, 3);

    // ── Map widget ────────────────────────────────────────────
    m_mapWidget = new MapWidget(this);
    m_mapWidget->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    m_mapWidget->setMinimumHeight(180);
    rootLayout->addWidget(m_mapWidget, 2);

    // ── Controls ─────────────────────────────────────────────
    auto *ctrlRow = new QHBoxLayout;
    ctrlRow->setSpacing(16);

    m_startBtn = new QPushButton("▶  START");
    m_pauseBtn = new QPushButton("⏸  PAUSE");
    m_resetBtn = new QPushButton("↺  RESET");

    styleButton(m_startBtn, QColor(0, 200, 100));
    styleButton(m_pauseBtn, QColor(255, 160, 0));
    styleButton(m_resetBtn, QColor(200, 50, 50));

    ctrlRow->addStretch();
    ctrlRow->addWidget(m_startBtn);
    ctrlRow->addWidget(m_pauseBtn);
    ctrlRow->addWidget(m_resetBtn);
    ctrlRow->addStretch();
    rootLayout->addLayout(ctrlRow);
}

void DashboardWidget::styleButton(QPushButton *btn, const QColor &accent)
{
    QFont f;
    f.setFamily("Courier New");
    f.setPixelSize(13);
    f.setBold(true);
    f.setLetterSpacing(QFont::AbsoluteSpacing, 2);
    btn->setFont(f);
    btn->setMinimumSize(140, 42);
    btn->setCursor(Qt::PointingHandCursor);

    QString hexColor = accent.name();
    QString style = QString(R"(
        QPushButton {
            background: rgba(%1,%2,%3,30);
            color: %4;
            border: 2px solid %4;
            border-radius: 6px;
            padding: 6px 18px;
        }
        QPushButton:hover {
            background: rgba(%1,%2,%3,70);
            border-color: %4;
        }
        QPushButton:pressed {
            background: rgba(%1,%2,%3,120);
        }
    )").arg(accent.red()).arg(accent.green()).arg(accent.blue()).arg(hexColor);
    btn->setStyleSheet(style);
}

void DashboardWidget::setupConnections()
{
    connect(m_engine, &FocusEngine::speedChanged,    m_speedGauge, &SpeedGaugeWidget::updateSpeed);
    connect(m_engine, &FocusEngine::speedChanged,    m_mapWidget,  &MapWidget::updateSpeed);
    connect(m_engine, &FocusEngine::gearChanged,     m_gearWidget, &GearWidget::updateGear);
    connect(m_engine, &FocusEngine::progressChanged, m_mapWidget,  &MapWidget::updateProgress);
    connect(m_engine, &FocusEngine::gearShiftTriggered, this, &DashboardWidget::onGearShifted);
    connect(m_engine, &FocusEngine::sessionCompleted,   this, &DashboardWidget::onSessionCompleted);
    connect(m_engine, &FocusEngine::stateChanged, this, [this]{ onStateChanged(); });

    connect(m_startBtn, &QPushButton::clicked, m_engine, &FocusEngine::start);
    connect(m_pauseBtn, &QPushButton::clicked, m_engine, &FocusEngine::pause);
    connect(m_resetBtn, &QPushButton::clicked, m_engine, &FocusEngine::reset);
}

void DashboardWidget::onGearShifted(int gear)
{
    m_gearWidget->triggerShiftAnimation();
    m_speedGauge->triggerGlowEffect();

    if (m_flashAnim->state() == QAbstractAnimation::Running)
        m_flashAnim->stop();
    m_flashAnim->start();

    m_statusLabel->setText(QString("⚡ GEAR %1 ENGAGED!").arg(gear));
}

void DashboardWidget::onSessionCompleted()
{
    m_statusLabel->setText("🏁 SESSION COMPLETE!");
    m_statusLabel->setStyleSheet("color: rgba(0,255,180,230); background: transparent;");
}

void DashboardWidget::onStateChanged()
{
    switch (m_engine->state()) {
    case FocusEngine::State::Running:
        m_statusLabel->setText("● DRIVING — STAY FOCUSED");
        m_statusLabel->setStyleSheet("color: rgba(0,230,255,220); background: transparent;");
        break;
    case FocusEngine::State::Paused:
        m_statusLabel->setText("⏸ PAUSED");
        m_statusLabel->setStyleSheet("color: rgba(255,160,0,220); background: transparent;");
        break;
    case FocusEngine::State::Idle:
        m_statusLabel->setText("● IDLE");
        m_statusLabel->setStyleSheet("color: rgba(100,160,200,200); background: transparent;");
        break;
    }
}

void DashboardWidget::updateStatusBar()
{
    int secs = m_engine->focusTimeSeconds();
    int h = secs / 3600;
    int m = (secs % 3600) / 60;
    int s = secs % 60;
    m_timerLabel->setText(QString("%1:%2:%3")
        .arg(h, 2, 10, QChar('0'))
        .arg(m, 2, 10, QChar('0'))
        .arg(s, 2, 10, QChar('0')));

    m_statsLabel->setText(QString("Distractions: %1  |  Idle penalties: %2")
        .arg(m_engine->totalDistractionsCount())
        .arg(m_engine->totalIdlePenalties()));
}

void DashboardWidget::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);

    QRectF r(0, 0, width(), height());

    // Main background
    QLinearGradient bg(r.topLeft(), r.bottomRight());
    bg.setColorAt(0.0, QColor(6, 12, 22));
    bg.setColorAt(0.5, QColor(10, 18, 32));
    bg.setColorAt(1.0, QColor(4, 10, 20));
    p.fillRect(r, bg);

    // Subtle grid lines (HUD aesthetic)
    p.setPen(QPen(QColor(0, 80, 140, 25), 1));
    int gridSize = 40;
    for (int x = 0; x < width(); x += gridSize)
        p.drawLine(x, 0, x, height());
    for (int y = 0; y < height(); y += gridSize)
        p.drawLine(0, y, width(), y);

    // Corner accent glows
    QRadialGradient cornerGlow(QPointF(0, 0), 200);
    cornerGlow.setColorAt(0, QColor(0, 100, 200, 30));
    cornerGlow.setColorAt(1, QColor(0, 50, 100, 0));
    p.fillRect(r, cornerGlow);

    // Outer border
    p.setPen(QPen(QColor(0, 140, 200, 80), 2));
    p.setBrush(Qt::NoBrush);
    p.drawRoundedRect(r.adjusted(1,1,-1,-1), 4, 4);

    // Flash overlay on gear shift
    if (m_flashAlpha > 0.01) {
        p.fillRect(r, QColor(0, 200, 255, static_cast<int>(m_flashAlpha * 40)));
    }
}
