#pragma once

#include <QMainWindow>

class DashboardWidget;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);

protected:
    void resizeEvent(QResizeEvent *event) override;

private:
    DashboardWidget *m_dashboard{nullptr};
};
